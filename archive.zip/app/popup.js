//Copyright (C) 2023 ading2210
//see README.md for more information

alert(`Error: You are running an older version of the script.

Try clearing your cache. If that does not work, go to https://edpuzzle.hs.vc and re-create the bookmarklet.`);